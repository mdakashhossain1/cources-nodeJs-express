const express = require('express');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const path = require('path');
const expressLayouts = require('express-ejs-layouts');
const viewController = require('./controllers/viewController');
const authViewController = require('./controllers/authViewController');
const { protect } = require('./middleware/auth');
const { restrictTo } = require('./middleware/rbac');
const { connectDB } = require('./config/database');
const courseRoutes = require('./routes/courseRoutes');
const userRoutes = require('./routes/userRoutes');
const { Course, User } = require('./models');
const adminRoutes = require('./routes/adminRoutes');
const session = require('express-session');
const authRoutes = require('./routes/authRoutes');

// Load environment variables
dotenv.config();

// Initialize express
const app = express();

// Database connection
connectDB().then(() => {
    console.log('Database connection established');
}).catch(err => {
    console.error('Database connection failed:', err);
    process.exit(1);
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static('public'));

// Session middleware
app.use(session({
    secret: process.env.SESSION_SECRET || 'sk-proj-aamEDZ8c9wxqLEKMjTF5xP5iLO7JKUhLtG6ZQ-b70Xab2VmaHQG0EEwX0Xd0fSKZW-NZeClf01T3BlbkFJF1IcWtIEaHP15-iQ6ocY14hJyaI8n',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    }
}));

// Make user data available to all views
app.use((req, res, next) => {
    res.locals.user = req.session.user;
    next();
});

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);
app.set('layout', 'layouts/layout');

// Routes
app.get('/', async (req, res) => {
    try {
        const courses = await Course.findAll({
            order: [['createdAt', 'DESC']],
            limit: 6 // Limit to show only 6 latest courses on home page
        });
        
        res.render('home', { 
            title: 'Welcome to CourseHub',
            user: req.session.user,
            courses: courses // Pass courses to the template
        });
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.render('home', { 
            title: 'Welcome to CourseHub',
            user: req.session.user,
            courses: [] // Pass empty array if error occurs
        });
    }
});
app.get('/auth/login', authViewController.getLoginPage);
app.get('/auth/register', authViewController.getRegisterPage);
app.get('/admin/dashboard', protect, async (req, res) => {
    if (req.session.user.role !== 'admin') {
        return res.redirect('/courses');
    }

    try {
        const courses = await Course.findAll({
            order: [['createdAt', 'DESC']]
        });
        
        res.render('admin/dashboard', { 
            title: 'Admin Dashboard',
            user: req.session.user,
            courses: courses
        });
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).render('error', { 
            error: 'Failed to fetch courses',
            user: req.session.user 
        });
    }
});
app.get('/profile', protect, viewController.getUserProfile);
app.get('/admin/courses', protect, restrictTo('admin'), (req, res) => {
    res.render('admin/courses', { 
        user: req.session.user,
        title: 'Course Management'
    });
});

app.use('/auth', authRoutes);
app.use('/', userRoutes);
app.use('/', adminRoutes);
app.use('/courses', courseRoutes);

// Protected routes
app.get('/courses', protect, async (req, res) => {
    try {
        const courses = await Course.findAll({
            order: [['createdAt', 'DESC']]
        });
        
        res.render('courses/index', { 
            title: 'All Courses',
            user: req.session.user,
            courses: courses
        });
    } catch (error) {
        console.error('Error fetching courses:', error);
        res.status(500).render('error', { 
            error: 'Failed to fetch courses',
            user: req.session.user 
        });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { error: err });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`Port ${PORT} is busy, trying ${PORT + 1}`);
    app.listen(PORT + 1);
  }
});

module.exports = app; 